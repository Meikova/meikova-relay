import os
import sys
import time
import json
import base64
import asyncio
import logging
import argparse
import unicodedata
from pathlib import Path
from typing import Optional
import websockets

# Ensure package is resolvable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from host_agent.protocol import Protocol
from host_agent.screen_capture import ScreenCapture
from host_agent.input_injector import InputInjector
from host_agent.clipboard_manager import ClipboardManager
from host_agent.file_manager import FileManager
from host_agent.terminal_manager import TerminalManager
from host_agent.system_manager import SystemManager
from host_agent.power_manager import PowerManager
from host_agent.audio_capture import AudioCapture
from host_agent.audio_playback import AudioPlayback

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("HostAgent")

class HostService:
    """Manages outbound WebSocket connection to Relay Server and streams desktop + handles all remote events."""

    def __init__(self, relay_url: str, room_id: str, pin: str, device_name: str = "Workstation", account: str = "", fps: int = 25, quality: int = 65):
        self.relay_url = relay_url
        self.room_id = room_id
        self.pin = pin
        self.device_name = device_name
        self.account = account
        self.fps = fps
        self.frame_interval = 1.0 / max(1, fps)
        self.quality = quality
        self.capture = ScreenCapture(quality=self.quality)
        self.file_manager = FileManager()
        self.running = True
        self.has_active_client = False
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None

        # Audio Capture & Stream
        self.audio_capture = AudioCapture(on_chunk=self._on_audio_chunk)
        self.audio_enabled = False
        self.audio_queue: Optional[asyncio.Queue] = None

        # Audio Playback (Client Mic -> Host Speakers)
        self.audio_playback = AudioPlayback()

        # Clipboard Sync
        self.clipboard = ClipboardManager(on_clipboard_change=self._on_local_clipboard_change)
        self.clipboard.start_listener()

        # Terminal Session
        self.terminal = TerminalManager(on_output=self._on_terminal_output)
        self.terminal.start()

    def _on_audio_chunk(self, chunk: bytes, rate: int, channels: int):
        if not self.audio_enabled or not self.has_active_client or not self.audio_queue or not self.loop or not self.loop.is_running():
            return
        try:
            b64 = base64.b64encode(chunk).decode("ascii")
            msg = json.dumps({
                "type": "audio_chunk",
                "data": b64,
                "rate": rate,
                "channels": channels
            })
            self.loop.call_soon_threadsafe(self._enqueue_audio, msg)
        except Exception:
            pass

    def _enqueue_audio(self, msg: str):
        if self.audio_queue:
            try:
                if self.audio_queue.full():
                    try:
                        self.audio_queue.get_nowait()
                    except Exception:
                        pass
                self.audio_queue.put_nowait(msg)
            except Exception:
                pass

    def _on_local_clipboard_change(self, text: str):
        if self.ws and self.has_active_client and self.loop and self.loop.is_running():
            asyncio.run_coroutine_threadsafe(
                self.ws.send(json.dumps({
                    "type": "clipboard_sync",
                    "text": text
                })),
                self.loop
            )

    def _on_terminal_output(self, output_text: str):
        if self.ws and self.has_active_client and self.loop and self.loop.is_running():
            asyncio.run_coroutine_threadsafe(
                self.ws.send(json.dumps({
                    "type": "terminal_output",
                    "data": output_text
                })),
                self.loop
            )

    async def _send_frames_loop(self, ws: websockets.WebSocketClientProtocol):
        logger.info(f"Frame streamer started targeting {self.fps} FPS")
        last_heartbeat = time.time()
        while self.running:
            start_time = time.perf_counter()

            frame_bytes = self.capture.capture_frame(force=False)
            if frame_bytes:
                try:
                    await ws.send(frame_bytes)
                except Exception as e:
                    logger.warning(f"Error sending frame: {e}")
                    break

            if time.time() - last_heartbeat > 10:
                try:
                    await ws.send(json.dumps({"type": "ping", "ts": time.time()}))
                    last_heartbeat = time.time()
                except Exception:
                    break

            elapsed = time.perf_counter() - start_time
            sleep_time = max(0.005, self.frame_interval - elapsed)
            await asyncio.sleep(sleep_time)

    async def _send_audio_loop(self, ws: websockets.WebSocketClientProtocol):
        logger.info("Audio streamer started")
        while self.running:
            try:
                if self.audio_queue:
                    msg = await self.audio_queue.get()
                    if self.has_active_client and self.audio_enabled:
                        await ws.send(msg)
                else:
                    await asyncio.sleep(0.05)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Audio stream error: {e}")
                break

    async def _receive_events_loop(self, ws: websockets.WebSocketClientProtocol):
        logger.info("Event listener started")
        async for raw_msg in ws:
            if isinstance(raw_msg, str):
                try:
                    event = json.loads(raw_msg)
                except Exception:
                    continue

                ev_type = event.get("type")

                # System & Room Control
                if ev_type == "client_connected":
                    logger.info("[+] Client connected! Streaming live.")
                    self.has_active_client = True
                    initial_frame = self.capture.capture_frame(force=True)
                    if initial_frame:
                        await ws.send(initial_frame)
                    await ws.send(json.dumps({
                        "type": "monitors_list",
                        "monitors": self.capture.monitors,
                        "active_id": self.capture.active_monitor_id
                    }))
                    await ws.send(json.dumps({
                        "type": "audio_capabilities",
                        "available": self.audio_capture.is_wasapi_available,
                        "sample_rate": self.audio_capture.sample_rate,
                        "channels": self.audio_capture.channels
                    }))
                    clip_text = self.clipboard.get_clipboard_text()
                    if clip_text:
                        await ws.send(json.dumps({
                            "type": "clipboard_sync",
                            "text": clip_text
                        }))
                    continue

                elif ev_type == "client_disconnected":
                    logger.info("[-] Client disconnected.")
                    self.has_active_client = False
                    self.audio_enabled = False
                    self.audio_capture.stop()
                    self.audio_playback.stop()
                    continue

                # Audio Stream Control (Host Speakers -> Client Browser)
                elif ev_type == "audio_stream_toggle":
                    self.audio_enabled = bool(event.get("enabled", False))
                    if self.audio_enabled:
                        self.audio_capture.start()
                    else:
                        self.audio_capture.stop()
                    await ws.send(json.dumps({
                        "type": "audio_stream_status",
                        "enabled": self.audio_enabled,
                        "sample_rate": self.audio_capture.sample_rate,
                        "channels": self.audio_capture.channels
                    }))
                    continue

                # Voice Intercom Control (Client Browser Mic -> Host Speakers)
                elif ev_type == "client_mic_toggle":
                    enabled = bool(event.get("enabled", False))
                    rate = int(event.get("sample_rate", 16000))
                    channels = int(event.get("channels", 1))
                    if enabled:
                        self.audio_playback.start(sample_rate=rate, channels=channels)
                    else:
                        self.audio_playback.stop()
                    await ws.send(json.dumps({
                        "type": "client_mic_status",
                        "enabled": enabled
                    }))
                    continue

                elif ev_type == "client_mic_chunk":
                    chunk_b64 = event.get("data", "")
                    if chunk_b64:
                        try:
                            pcm_data = base64.b64decode(chunk_b64)
                            if not self.audio_playback.running:
                                rate = int(event.get("rate", 16000))
                                channels = int(event.get("channels", 1))
                                self.audio_playback.start(sample_rate=rate, channels=channels)
                            self.audio_playback.play_chunk(pcm_data)
                        except Exception as e:
                            logger.debug(f"Audio playback chunk error: {e}")
                    continue

                # Multi-Monitor Switch
                elif ev_type == "switch_monitor":
                    mon_id = int(event.get("monitor_id", 1))
                    self.capture.set_active_monitor(mon_id)
                    w, h = self.capture.resolution
                    await ws.send(json.dumps({
                        "type": "host_ready",
                        "width": w,
                        "height": h,
                        "monitors": self.capture.monitors,
                        "active_id": mon_id
                    }))
                    initial_frame = self.capture.capture_frame(force=True)
                    if initial_frame:
                        await ws.send(initial_frame)
                    continue

                # Quality / FPS Preset
                elif ev_type == "set_quality_preset":
                    preset = event.get("preset", "balanced")
                    if preset == "speed_60":
                        self.capture.quality = 45
                        self.frame_interval = 1.0 / 60.0
                    elif preset == "crisp_hd":
                        self.capture.quality = 85
                        self.frame_interval = 1.0 / 20.0
                    elif preset == "grayscale":
                        self.capture.quality = 35
                        self.frame_interval = 1.0 / 25.0
                    else: # balanced
                        self.capture.quality = 65
                        self.frame_interval = 1.0 / 30.0
                    logger.info(f"Applied Quality Preset: {preset} (Quality: {self.capture.quality})")
                    continue

                # Terminal Input
                elif ev_type == "terminal_input":
                    cmd = event.get("command", "")
                    self.terminal.send_input(cmd)
                    continue

                # Telemetry & Diagnostics
                elif ev_type == "telemetry_request":
                    stats = SystemManager.get_hardware_telemetry()
                    await ws.send(json.dumps({
                        "type": "telemetry_response",
                        "data": stats
                    }))
                    continue

                elif ev_type == "process_list_request":
                    procs = SystemManager.get_process_list(limit=50)
                    await ws.send(json.dumps({
                        "type": "process_list_response",
                        "processes": procs
                    }))
                    continue

                elif ev_type == "process_kill_request":
                    pid = int(event.get("pid", 0))
                    ok = SystemManager.kill_process(pid)
                    await ws.send(json.dumps({
                        "type": "process_kill_response",
                        "pid": pid,
                        "success": ok
                    }))
                    continue

                # Power Management
                elif ev_type == "power_action":
                    action = event.get("action")
                    if action == "lock":
                        PowerManager.lock_workstation()
                    elif action == "restart":
                        PowerManager.restart_machine()
                    elif action == "shutdown":
                        PowerManager.shutdown_machine()
                    continue

                # File Browser
                elif ev_type == "file_browse_request":
                    path = event.get("path", "")
                    data = self.file_manager.browse_path(path)
                    await ws.send(json.dumps({
                        "type": "file_browse_response",
                        "data": data
                    }))
                    continue

                # File Delete Request
                elif ev_type == "file_delete_request":
                    filepath = unicodedata.normalize('NFC', event.get("filepath", ""))
                    ok = self.file_manager.delete_item(filepath)
                    await ws.send(json.dumps({
                        "type": "file_delete_response",
                        "filepath": filepath,
                        "success": ok
                    }))
                    continue

                # File Create Folder Request
                elif ev_type == "file_create_folder_request":
                    parent_dir = event.get("parent_dir", "")
                    folder_name = event.get("name", "")
                    res = self.file_manager.create_folder(parent_dir, folder_name)
                    await ws.send(json.dumps({
                        "type": "file_create_folder_response",
                        "result": res
                    }))
                    continue

                # File Download Request
                elif ev_type == "file_download_request":
                    filepath = unicodedata.normalize('NFC', event.get("filepath", ""))
                    transfer_id = event.get("transfer_id", f"dl_{int(time.time()*1000)}")
                    if os.path.isfile(filepath):
                        fname = os.path.basename(filepath)
                        fsize = os.path.getsize(filepath)
                        await ws.send(json.dumps({
                            "type": "file_download_start",
                            "transfer_id": transfer_id,
                            "filename": fname,
                            "filesize": fsize
                        }))
                        chunk_size = 64 * 1024
                        try:
                            with open(filepath, "rb") as f:
                                while True:
                                    chunk = f.read(chunk_size)
                                    if not chunk:
                                        break
                                    await ws.send(json.dumps({
                                        "type": "file_download_chunk",
                                        "transfer_id": transfer_id,
                                        "data": base64.b64encode(chunk).decode("ascii")
                                    }))
                            await ws.send(json.dumps({
                                "type": "file_download_finish",
                                "transfer_id": transfer_id,
                                "filename": fname
                            }))
                        except Exception as e:
                            await ws.send(json.dumps({
                                "type": "file_download_error",
                                "transfer_id": transfer_id,
                                "message": str(e)
                            }))
                    else:
                        await ws.send(json.dumps({
                            "type": "file_download_error",
                            "transfer_id": transfer_id,
                            "message": "Tệp không tồn tại"
                        }))
                    continue

                # Clipboard Sync from Client
                elif ev_type == "clipboard_sync":
                    new_text = event.get("text", "")
                    if new_text:
                        self.clipboard.set_clipboard_text(new_text)
                    continue

                # File Upload Events
                elif ev_type == "file_upload_start":
                    transfer_id = event.get("transfer_id", "default")
                    filename = event.get("filename", "unknown.bin")
                    filesize = int(event.get("filesize", 0))
                    checksum = event.get("checksum", "")
                    target_dir = event.get("target_dir", "")
                    dest_path = self.file_manager.start_upload(transfer_id, filename, filesize, checksum, target_dir)
                    await ws.send(json.dumps({
                        "type": "file_upload_ack",
                        "transfer_id": transfer_id,
                        "status": "ready"
                    }))
                    continue

                elif ev_type == "file_upload_chunk":
                    transfer_id = event.get("transfer_id")
                    chunk_b64 = event.get("data", "")
                    chunk_bytes = base64.b64decode(chunk_b64)
                    res = self.file_manager.write_chunk(transfer_id, chunk_bytes)
                    await ws.send(json.dumps({
                        "type": "file_upload_progress",
                        "transfer_id": transfer_id,
                        "progress": res.get("progress", 0)
                    }))
                    continue

                elif ev_type == "file_upload_finish":
                    transfer_id = event.get("transfer_id")
                    res = self.file_manager.finish_upload(transfer_id)
                    await ws.send(json.dumps({
                        "type": "file_upload_result",
                        "transfer_id": transfer_id,
                        "result": res
                    }))
                    continue

                # Mouse & Keyboard Input
                elif ev_type == "mouse_move":
                    InputInjector.mouse_move(event["x"], event["y"], monitor_rect=self.capture.active_monitor_rect)
                elif ev_type == "mouse_down":
                    InputInjector.mouse_down(event["button"])
                elif ev_type == "mouse_up":
                    InputInjector.mouse_up(event["button"])
                elif ev_type == "mouse_wheel":
                    InputInjector.mouse_wheel(event["delta_y"])
                elif ev_type == "key_down":
                    InputInjector.key_down(event["vk"])
                elif ev_type == "key_up":
                    InputInjector.key_up(event["vk"])
                elif ev_type == "text_input":
                    InputInjector.type_unicode(event["text"])
                elif ev_type == "block_input":
                    blocked = bool(event.get("blocked", False))
                    ok = InputInjector.set_block_input(blocked)
                    await ws.send(json.dumps({"type": "block_input_response", "blocked": blocked, "success": ok}))
                elif ev_type == "chat_message":
                    msg_text = str(event.get("message", "")).strip()
                    sender = str(event.get("sender", "Kỹ thuật viên"))
                    logger.info(f"[Chat from {sender}]: {msg_text}")
                    if hasattr(self, "on_chat_message") and self.on_chat_message:
                        self.on_chat_message(sender, msg_text)
                    await ws.send(json.dumps({"type": "chat_ack", "status": "delivered"}))
                elif ev_type == "ping":
                    await ws.send(json.dumps({"type": "pong", "ts": event.get("ts", 0)}))

    async def start(self):
        self.loop = asyncio.get_running_loop()
        w, h = self.capture.resolution
        logger.info(f"Starting Host Agent for Room [{self.room_id}] (Res: {w}x{h})")

        while self.running:
            try:
                logger.info(f"Connecting to Relay Server at {self.relay_url} ...")
                async with websockets.connect(
                    self.relay_url,
                    ping_interval=20,
                    ping_timeout=15,
                    max_size=20 * 1024 * 1024
                ) as ws:
                    self.ws = ws
                    init_pkt = json.dumps({
                        "type": "init_host",
                        "room_id": self.room_id,
                        "pin": self.pin,
                        "width": w,
                        "height": h,
                        "device_name": self.device_name,
                        "account": self.account,
                        "os_info": "Windows 11 x64",
                        "monitors": self.capture.monitors
                    })
                    await ws.send(init_pkt)

                    ack_raw = await ws.recv()
                    ack = json.loads(ack_raw) if isinstance(ack_raw, str) else {}
                    if ack.get("status") != "ok":
                        logger.error(f"Relay authentication rejected: {ack.get('message')}")
                        await asyncio.sleep(5)
                        continue

                    logger.info(f"Host Registered Successfully! Room: {self.room_id}")

                    self.audio_queue = asyncio.Queue(maxsize=50)
                    send_task = asyncio.create_task(self._send_frames_loop(ws))
                    audio_task = asyncio.create_task(self._send_audio_loop(ws))
                    recv_task = asyncio.create_task(self._receive_events_loop(ws))

                    done, pending = await asyncio.wait(
                        [send_task, audio_task, recv_task],
                        return_when=asyncio.FIRST_COMPLETED
                    )
                    for t in pending:
                        t.cancel()
                    self.audio_capture.stop()
                    self.audio_playback.stop()

            except (websockets.ConnectionClosed, ConnectionRefusedError, OSError) as e:
                logger.warning(f"Connection lost ({e}). Reconnecting in 3s...")
                await asyncio.sleep(3)
            except Exception as e:
                logger.error(f"Unexpected error: {e}. Reconnecting in 5s...")
                await asyncio.sleep(5)

def main():
    parser = argparse.ArgumentParser(description="Titan Remote Desktop - Host Agent")
    parser.add_argument("--relay", default="ws://127.0.0.1:8080", help="Relay Server URL")
    parser.add_argument("--room", default="RD-8888", help="Room ID / Session Code")
    parser.add_argument("--pin", default="123456", help="Security PIN")
    parser.add_argument("--name", default="Workstation-PC", help="Device Name")
    parser.add_argument("--account", default="", help="Linked user account (email or username)")
    parser.add_argument("--fps", type=int, default=25, help="Target capture FPS")
    parser.add_argument("--quality", type=int, default=65, help="JPEG quality 1-100")

    args = parser.parse_args()
    service = HostService(
        relay_url=args.relay,
        room_id=args.room,
        pin=args.pin,
        device_name=args.name,
        account=args.account,
        fps=args.fps,
        quality=args.quality
    )

    try:
        asyncio.run(service.start())
    except KeyboardInterrupt:
        logger.info("Host Agent stopped by user.")

if __name__ == "__main__":
    main()
